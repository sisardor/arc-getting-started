#! /usr/bin/env python
import argparse
import os
import time

parser = argparse.ArgumentParser()
parser.add_argument("--importFilepath",	help="Entity Id")
parser.add_argument("--entityId",	 	help="Entity Id")
parser.add_argument("--entities",	 	help="Entity Id")
parser.add_argument("--inputStartFrame",help="project colorspace")
parser.add_argument("--startFrame", 	help="project x resolution")
parser.add_argument("--endFrame", 		help="project y resolution")
parser.add_argument("--inputColorSpace",help="project pixel aspect ratio")
parser.add_argument("--inputX",	 	help="Entity Id")
parser.add_argument("--inputY",	 	help="Entity Id")
parser.add_argument("--head",	 	help="Entity Id")
parser.add_argument("--tail",	 	help="Entity Id")

args = parser.parse_args()

time.sleep( 0 ); os.write(3, "0")
time.sleep( 2 ); os.write(3, "10")
time.sleep( 2 ); os.write(3, "25")
time.sleep( 1 ); os.write(3, "50")
time.sleep( 1 ); os.write(3, "52")
time.sleep( 1 ); os.write(3, "55")
time.sleep( 1 ); os.write(3, "65")
time.sleep( 1 ); os.write(3, "70")
time.sleep( 3 ); os.write(3, "75")
time.sleep( 2 ); os.write(3, "100")
time.sleep( 5 );

print args
print "Process completed; no errors"

