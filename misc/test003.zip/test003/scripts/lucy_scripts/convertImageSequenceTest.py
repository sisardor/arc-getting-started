import sys
from time import sleep
from pprint import pprint as pp

pp(sys.argv)
sleep(10)
