#!/Applications/Nuke9.0v6/Nuke9.0v6.app/Contents/MacOS/Nuke9.0v6 -t -nc
import nuke

print '\nok\n'