import traceback
import os, sys
import functools
import copy
import argparse
import re
import shutil
import glob
import getpass
import json

#these need addressing, making into a module
sys.path.append("/hdx/cg/pydraulx")
sys.path.append("/hdx/cg/lucy_workstations/python2.6/lib/python2.6/site-packages/requests-2.1.0-py2.6.egg")
sys.path.append('/hdx/sys/lucy_scripts')



'''
TODO:
	IMPLEMENT CAMERA PUBLISH SCRIPT

'''


'''
['/hdx/sys/lucy_scripts/convertImageSequence.py', '--source', '/mnt/x1/hdx/cg/maya/scripts/hdxBrowser/trevorDev/testPlate',
'--entity', '54513295128acb6238b48f9d', '--start', '1001', '--end', 'null']
convertImageSequence("21, 33, 23")

/hdx/sys/python/bin/python2.7 /hdx/sys/lucy_scripts/convertImageSequence.py --entities "21,33,23"

'''
if __name__ == '__main__':
    print "main"
    parser = argparse.ArgumentParser(description='Process plate entity publish.')
    parser.add_argument('--entities',  dest='entities', action='store', help='Entity path to root')
    parser.add_argument('--fileImportPath',  help='fileImportPath')
    parser.add_argument('--outputPath',  help='outputPath')
    parser.add_argument('fargs', nargs=argparse.REMAINDER)

    args = vars(parser.parse_args())
    mavisEntities={}
    currentUser = getpass.getuser()
    print args

    sys.exit()
