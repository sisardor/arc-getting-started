import traceback
import os, sys
import functools
import copy
import argparse
import re
import shutil
import glob
import getpass
import json

#these need addressing, making into a module
sys.path.append("/hdx/cg/pydraulx")
sys.path.append("/hdx/cg/lucy_workstations/python2.6/lib/python2.6/site-packages/requests-2.1.0-py2.6.egg")
sys.path.append('/hdx/sys/lucy_scripts')
# import imageHeaderInfo

import mavis
standalone=False

try:
    import nuke
except ImportError,e:
    standalone=True
'''
###example plate entity:
conn.find('/projects/test006/shots/tst001/plates/client')
[{u'publishes': [], u'name': u'client', u'links': [], u'updatedAt': None, u'createdBy': u'superuser', u'activity': [],
            u'input': {u'colorspace': u'Cineon', u'inX': 1920, u'inY': 1080, u'inPixelAspect': 2.3999999999999999, u'inFilter': 0, u'inCDL': 0},
            u'path': {u'name': u'client', u'collection': u'entities', u'file': None, u'directory': u'projects/test006/shots/tst001/plates',
                        u'path': u'/projects/test006/shots/tst001/plates/client', u'model': u'plates', u'root': u'/hdx'},
            u'_id': u'/projects/test006/shots/tst001/plates/client', u'createdAt': u'2014-06-18T01:04:14.999Z'}]

###example nodeDict {
    'read1' : {'nodeType':'Read', args=[], 'kwargs': {'file':'sequence', 'first':sfrm, 'last':efrm, 'colorspace':None, raw=0}  },
    'colourspace1' : {'nodeType':'Colorspace', args=[], 'kwargs': {'name':'Colorspace'}  },
    'writeLin' : {'nodeType':'Write', args=[], 'kwargs': {'raw': 1, 'file':"%s/%s_LIN.%s.exr" 0}  },
    'reformat1' : {'nodeType':'Reformat', args=[], 'kwargs': {'type':"scale", 'scale':scale}  },
    'writeProxy' : {'nodeType':'Write', args=[], 'kwargs': {'file':'sequence', 'first':sfrm, 'last':efrm, 'colorspace':None, raw=0}  },
}

#NB - ALWAYS resize in log colorspace, as it has an effect on the image.
#also certain rezolutions are only available to certain colorspaces - ie if it is size A the file is Cineon. etc etc

testPlatePath = "/mnt/x1/hdx/cg/maya/scripts/hdxBrowser/trevorDev/testPlate/TC_066_3115.%04d.dpx"

 ### example command line call
$ nuke -t /hdx/cg/lucy/scripts/convertImageSequence.py \
--source=/full/path/to/source/sequence.%04d.exr \
--dest=/projects/test006/shots/tst001/plates/client/publishes/0001/sequence.%04d.exr \
--entity=/projects/test006/shots/tst001/plates/client

#nuke -t /hdx/cg/lucy/scripts/convertImageSequence.py --source=/mnt/x1/hdx/cg/maya/scripts/hdxBrowser/trevorDev/testPlate/TC_066_3115.%04d.dpx --dest=/hdx/projects/test006/shots/tst001/plates/autoIngest/publishes/0039/sequence.%04d.exr --entity=/projects/test006/shots/tst001/plates/client
#new script:
/hdx/cg/scripts/nuke8args /hdx/sys/lucy_scripts/convertImageSequence.py --source /mnt/x1/hdx/cg/maya/scripts/hdxBrowser/trevorDev/testPlate --entity /projects/mavisTesting/shot/sh_ot1_012/plates/client1 --start 1001 --end null

/hdx/sys/python/bin/python2.7 /hdx/sys/lucy_scripts/convertImageSequence.py --entities "21,33,23"

nuke -t /hdx/sys/lucy_scripts/convertImageSequence.py --entities "21,33,23"
'''

conn = mavis.Mavis('trevor', 'password')
#project defaults os a dict of external default values to be stored (somewhere) for plates.
#These are cascading /facility/project/shot values for entity (plate) settings
PROJECT_DEFAULTS = {'colorspace': 'Linear', 'xResolution': 1080, 'yResolution': 1080, 'pixelAspect': 1, 'filter': 0, 'CDL': 0}
start=0
end=0

nukeNodes = { 'read1' : {'nodeType':'Read', 'args':[], 'kwargs': {'file':'sequence', 'first':1, 'last':10, 'raw':1, 'name':'read1'}},
    'reformat1' : {'nodeType':'Reformat', 'args':[], 'kwargs': {'type':"to box", 'scale':'scale', 'center':True, 'name':'reformat1'}  },
    'toAlexaLogC' : {'nodeType':'OCIOColorSpace', 'args':[], 'kwargs': {'name':'toAlexaLogC'}  },
    'writeLin' : {'nodeType':'Write', 'args':[], 'kwargs': {'raw': 1, 'file':"%s/%s_LIN.%s.exr",  'first':start, 'last':end, 'file_type':'exr','name':'writeLin' }  },
    'reformat2' : {'nodeType':'Reformat', 'args':[], 'kwargs': {'name': 'proxyResize', 'type':"scale", 'scale':'scale', 'name':'reformat2'}  },
    'toLinear' : {'nodeType':'OCIOColorSpace', 'args':[], 'kwargs': {'in_colorspace':'linear', 'out_colorspace':'linear', 'name':'toLinear'}  },
    'CopyMetaData1': {'args': [], 'nodeType': 'CopyMetaData', 'kwargs': {'imageMetadatafilterMode': 'keys and values', 'metadatafilterMode': 'keys and values', 'mergeMode': 'Image+Meta', 'name':"CopyMetaData1"} },
    'writeProxy' : {'nodeType':'Write', 'args':[], 'kwargs': {'name':'writeProxy', 'file':'sequence', 'first':start, 'last':end, 'raw':1, 'name':'writeProxy'}  },
    }


#global re compilations. These are used at various stages in
#this file. Compiled here for speed and re-use
groupByVersionNumberPattern=re.compile("_v\d+")
groupByFileSequenceNumber=re.compile("\.\d+\.")
containsSequenceFormat = re.compile("%0\dd")
numbersOnlyFormat = re.compile("\d+")

# this array used to calculate progess,
# see `progressHandler()` function
_allFrames = []
_completedFrames = []

def makeSequenceFromFilepath(filePath):
    rVal=None
    imageNumber=groupByFileSequenceNumber.findall(filePath)
    if imageNumber:
        frameNumber = numbersOnlyFormat.findall(imageNumber[-1])
        rVal=filePath.replace(frameNumber[-1], "%s0%sd" %("%", str(len(frameNumber[-1]))))
    return rVal



def getReadMetadata(readNode):
    '''
    return us a dict of the colorspace, X and Y for a plate.
    Plate is read in to nuke as a read node
    the metadata needs its keys to be renamed to match the project so we can compare the dict
    '''
    readMetadata= nukeNodes['read1'].metadata()
    print '\n'
    print readMetadata
    print '\n'
    if not readMetadata:
        print "\nERROR - cannot find read node metadata. Make sure filepath exists"
        print nukeNodes['read1'].knob("file").getValue()
    try:
        return {'input/width': readMetadata[ 'input/width'], 'input/height': readMetadata[ 'input/height']}
    except Exception,e:
        print e
        print readMetadata
        print readNode.knob('file').getValue()
        raise

def getProjectMetadata(projectDict):
    '''
    query mavis for the project plate settings.
    Here we are creating a dict of values to compare with ones created
    for the actual plate
    wrapper around getting 2 dicts that are the same
    (normalizing so that both have same keys)
    '''
    print '\n'
    print projectDict
    print '\n'
    projectSize=projectDict['fields']['project_resolution']
    projectRes=(1080, 720)
    return {'input/width': projectRes[0], 'input/height': projectRes[1], 'input/colorspace':projectDict['fields']['colorspace_settings'] }


def renameFrames(filepath):
    renders=glob.glob(filepath.replace(".%04d", ".*"))
    linSearch=re.compile("_LIN")
    exampleFileName=""
    if not linSearch.findall(renders[0]):
        for aFile in renders:
            try:
                temp=aFile.split(".")
                newName = "%s_LIN.%s.%s"%(temp[0], temp[1], temp[2])
                print newName
                exampleFileName=newName
                os.rename(aFile, newName)
            except Exception,e:
                print temp
                print e

    return makeSequenceFromFilepath(exampleFileName)

#frame renumbering---------------------------------------------------------------------------------------------
def renumberRenders(filepath, startframe):
    '''
    nukes frame_mode:start_at:1001 was getting confused at our frame numbering (sometimes starting at -1)
    here we are renumbering the frames, being careful not to overwrite any files if the original frame range
    covers the startframe, by going first to a temporary range (original + 1000000), then to the desired one
    extension == '.dpx' or '.exr'
    returns <tuple> ( (original start and end frame) , (new start and end frame) )
    '''
    print "renumberRenders %s %s" %(filepath, str(startframe))
    sequenceNumberSearch=re.compile("\.[\-]*\d+\.")
    numberSearch=re.compile("\d+")
    renders=glob.glob(filepath.replace(".%04d", ".*"))
    #renders=sorted([os.path.join(renderPath, x) for x in os.listdir(renderPath) if os.path.splitext(os.path.join(renderPath, x))[-1]==extension])
    dataDict={}
    try:
        for imageIndex in range(len(renders)):
            originalImageString =sequenceNumberSearch.findall(renders[imageIndex])[-1]
            originalImageNumber = originalImageString.replace(".", "")
            newImageNumber=imageIndex+startframe
            intermediateImageNumber=int(originalImageNumber)+1000000
            folder, filename = os.path.split(renders[imageIndex])

            dataDict[imageIndex]={'origName':renders[imageIndex], 'origNumber':originalImageNumber,
                                                'intNumber':intermediateImageNumber, 'newNumber':newImageNumber}

            # this array used to calculate progess, see `progressHandler()` function
            _allFrames.append(newImageNumber);



    except Exception, e:
        print "ERROR: Cannot determine rename dict"
        print e
        print sequenceNumberSearch.findall(renders[imageIndex])
        print renders
        print filepath
        print imageIndex
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stdout)

    try:
        for item in sorted(dataDict.keys()):
            #rename to intermediate number (1000000+original)
            itemDict=dataDict[item]
            interemediateName = itemDict['origName'].replace("."+itemDict['origNumber']+".", "."+str(itemDict['intNumber'])+".")
            dataDict[item]['intName']=interemediateName
            os.rename( itemDict['origName'], interemediateName)
    except Exception, e:
        print "ERROR: renaming to intermediate filename"
        print e
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stdout)

    try:
        for item in sorted(dataDict.keys()):
            #rename FROM intermediate number (1000000+original) TO final
            renameDict=dataDict[item]
            finalName = renameDict['intName'].replace("."+str(renameDict['intNumber'])+".", "."+str(renameDict['newNumber'])+".")
            renameDict['finalName']=finalName
            os.rename( renameDict['intName'], finalName)

    except Exception, e:
        print "ERROR: renaming to final filename"
        print e
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stdout)
        print itemDict['intName'], finalName

    start = dataDict[dataDict.keys()[0]]
    last=dataDict[len(dataDict)-1]
    return ((start['origNumber'], last['origNumber']), (start['newNumber'], last['newNumber']))




def importPlateAction(mavisEntities, outputPath=None):
    print "importPlateAction"
    #first instantiate the nodes in Nuke (Read, Colorspace, Log2Lin, Resize, Write)
    for aNodeName, aNode in nukeNodes.iteritems():
        nukeNodes[aNodeName] = nodeFactory(aNode)
        #nukeNodes[aNodeName]['node'] = nodeFactory(aNode)

    #point the read node to the supplied path
    fileImportPath = str(mavisEntities['plates']['fileImportPath'])


    #VERSION CODE HERE......................................................................................................
    #kay - we need to create a NEW version here.
    #also the filepath is slightly wrong, needs the ".%04d.exr" part adding
    publishes=conn.get("api/Entities/%s/publishes"% str(mavisEntities['plates']['id']) )
    print publishes
    outputDir = publishes[0]['path']
    if outputPath:
        outputDir = outputPath
    print outputDir



    #lastVersion = "%s.%s" % (publishes[0]['major'], publishes[0]['minor'])
    filename=os.path.basename(fileImportPath)
    lastVersion=os.path.split(outputDir)[-1]
    newFileName="%s_%s_%s.%s" %(str(mavisEntities['plates']['type']),  str(mavisEntities['plates']['name']), str(lastVersion), ".".join(filename.split(".")[1:]) )
    outputPath=os.path.join(outputDir, newFileName)

    #goo = os.path.join(mavisEntities['plates']['path'], mavisEntities['plates']['name'], str("%04d"%lastVersion) )
    #print goo
    #if not os.path.exists(goo):
    #    try:
    #        os.makedirs(goo)
    #    except Exception,e :
    #        print "ERROR making directories"
    #        print e

    #print newFileName
    #outputFile=os.path.join(goo, newFileName)




    readNode=nuke.toNode('read1')
    readNode.knob('file').setValue(fileImportPath)
    #nukeNodes['read1'].knob('file').setValue(fileImportPath)
    plate=mavisEntities['plates']

    plateMetadata=getReadMetadata(readNode)
    plateMetadata['input/colorspace']=plate['fields']['inputColorSpace']

    projectMetadata=getProjectMetadata(mavisEntities['projects'])

    renderDir = os.path.dirname(fileImportPath)
    #reset the read nodes 'file' value to nothing so it doesnt freak out that the fames are now unavailable
    readNode.knob('file').setValue("None")

    #rename/renumber
    renamedFrames = renameFrames(fileImportPath)

    ####### WE HAVE RENAMED THE FRAMES HERE ###################################
    #make first frame number begin with 1000
    #originalRange, frameRange = renumberRenders(renamedFrames, 1000)
    originalRange, frameRange = renumberRenders(renamedFrames, 1000)

    #move files to required location....
    #shutil.move(renamedFrames, newFolder)
    #renamedFrames.replace(os.path.basedir(renamedFrames), newFolder)

    #renamed/moved files. Set read node to new files here...
    readNode.knob('file').setValue(renamedFrames)
    readNode.knob('first').setValue(frameRange[0])
    readNode.knob('last').setValue(frameRange[1])
    print originalRange, frameRange

    print "reset frames to %s" %renamedFrames
    platename=os.path.basename(renamedFrames).split(".")[0]

    #if input is different from projectSettings, pass the frames through the Nuke network
    #changing the items that are different
    if copy.copy(projectMetadata).update(plateMetadata) != projectMetadata:
        #keeping track of last node in tree so we know what to attach to what
        lastNode=readNode

        outputFormat = "%s %s 1" %(projectMetadata['input/width'], projectMetadata['input/height'])
        nukeFormat = nuke.addFormat( outputFormat )
        inputFormat = "%s %s 1" %(plateMetadata['input/width'], plateMetadata['input/height']) #ASPECT RATIO ????
        currentColorspace=plateMetadata['input/colorspace']

        #if we need to resize, move first to a Cineon colorspace
        if not outputFormat == inputFormat:
            toAlexaLogC=nuke.toNode('toAlexaLogC')
            toAlexaLogC.setInput(0, lastNode)
            toAlexaLogC.knob("in_colorspace").setValue(str(plateMetadata['input/colorspace']))
            toAlexaLogC.knob("out_colorspace").setValue("AlexaV3LogC")
            currentColorspace="AlexaV3LogC"
            lastNode=toAlexaLogC
            reformat1=nuke.toNode("reformat1")
            reformat1.knob("box_width").setValue(projectMetadata['input/width'])
            #reformat1.knob("format").setValue(nukeFormat)
            reformat1.setInput(0, lastNode)
            lastNode=reformat1

        #previous node(s) are optional, this one added anyway
        toLinear=nuke.toNode('toLinear')
        toLinear.setInput(0, lastNode)
        toLinear.knob("in_colorspace").setValue(currentColorspace)
        toLinear.knob("out_colorspace").setValue("linear")
        lastNode=toLinear

        #set up the write node
        writeLin=nuke.toNode('writeLin')
        writeLin.knob("file").setValue(outputPath)
        writeLin.knob("file_type").setValue(3)

        #frameTotal ="%d" %(int(frameRange[1] - frameRange[0]))
        # writeLin.knob("afterFrameRender").setValue('os.write(3,"%d/' + str(frameRange[1]) +'"%nuke.frame())')
        writeLin.knob("afterFrameRender").setValue('progressHandler()')

        writeLin.setInput(0, lastNode)
        #do the render
        try:
            nuke.executeMultiple([writeLin,], ([frameRange[0],frameRange[1],1],))
        except Exception,e:
            print e
    else:
        print "do nothing"
    projectPath=mavisEntities['projects']['path']
    #projectPath = "/mnt/x3/projects/mavisTest" renamedFrames
    n_script=os.path.join(os.path.dirname(renamedFrames), "%s_publish.nknc"%platename)
    nuke.scriptSave( "%s" %( n_script ) )

def progressHandler():
    _completedFrames.append( nuke.frame() )
    percentage = float(len(_completedFrames))/float(len(_allFrames)) * 100;
    text = '%s out of %s'%( str(len(_completedFrames)), str(len(_allFrames)) )

    response = {};
    response['percentage'] = percentage;
    response['text'] = text;

    os.write(3, json.dumps(response))


 # NUKE NODE CODE -----------------------------------------------------------------------------------------------------------------
def nodeFactory(nodeDict):
    '''
    a node creator. Pass a dict with 'nodeType'<str>, 'args'<list> and 'kwargs'<dict> keys
    All values must exist, but may be empty.
    Return a pointer to the newly created item or None on error
    '''
    try:
        if hasattr(nuke.nodes, nodeDict['nodeType']):
            #get a pointer to the function
            func = getattr(nuke.nodes, nodeDict['nodeType'])
            #pass required args and kwargs to the func as list and dict
            aNode = func( *nodeDict['args'], **nodeDict['kwargs'])
            return aNode
    except Exception, e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_tb(exc_traceback, file=sys.stdout)
        print e
        print nodeDict
        return None


def connectNodes(srcNode, dstNode, connectionIndex):
    '''
    Connect srcNode to dstNode's input at index connectionIndex
    return True on success or False on error
    '''
    try:
        dstNode.setInput( connectionIndex, srcNode )
        return True
    except Exception, e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_tb(exc_traceback, file=sys.stdout)
        print e
        return False

def writeSelectedNodesToDict():
    '''
    NUKE:
    writes all selected nodes' properties to a dict
    which is then returned
    '''
    rDict={'connections':{}}
    for aNode in nuke.selectedNodes():
        nodeDict={'nodeType': '%s'%aNode.Class(), 'args': [], 'kwargs': {}}
        aKnob = aNode.writeKnobs()
        tokenized = [x for x in aKnob.split("\n") if x]
        for anItem in tokenized:
            key, val = anItem.split(" ", 1)
            if val in ['true', "True"]:
                val=True
            if val in ['false', "False"]:
                val=False

            #if the vaue is default, there is no point worrying about it
            if hasattr(aNode[key], 'defaultValue'):
                defaultVal = aNode[key].defaultValue()
                try:
                    if int(val) == int(defaultVal):
                        continue
                except ValueError, e:
                    pass

            #get rid of empty strings too (ADDED 15May2015) - may be problematic
            if val ==  '""' or val ==  '" "':
                continue
            nodeDict['kwargs'][key]=val

        rDict[aNode.name()] = nodeDict

    #created nodeDict, now check and record connections
    for aNode in nuke.selectedNodes():
        if aNode.inputs():
            for inputIndex in range(aNode.inputs()):
                #srcNode is a node that feeds into this node
                srcNode=aNode.input(inputIndex).name()
                if rDict['connections'].has_key(srcNode):
                    rDict['connections'][srcNode].append( (inputIndex, aNode.name() ) )
                else:
                    rDict['connections'][srcNode]= [ (inputIndex, aNode.name() ) ]

    return rDict


'''
['/hdx/sys/lucy_scripts/convertImageSequence.py', '--source', '/mnt/x1/hdx/cg/maya/scripts/hdxBrowser/trevorDev/testPlate',
'--entity', '54513295128acb6238b48f9d', '--start', '1001', '--end', 'null']
convertImageSequence("21, 33, 23")

/hdx/sys/python/bin/python2.7 /hdx/sys/lucy_scripts/convertImageSequence.py --entities "21,33,23"

'''
if __name__ == '__main__':
    print "main"
    parser = argparse.ArgumentParser(description='Process plate entity publish.')
    parser.add_argument('--entities',  dest='entities', action='store', help='Entity path to root')
    parser.add_argument('--fileImportPath',  help='fileImportPath')
    parser.add_argument('--outputPath',  help='outputPath')
    parser.add_argument('fargs', nargs=argparse.REMAINDER)

    parser.add_argument('--entity',  dest='entity', action='store', help='Entity path to root')
    parser.add_argument('--inputStartFrame')
    parser.add_argument('--startFrame')
    parser.add_argument('--endFrame')
    parser.add_argument('--inputColorSpace')
    parser.add_argument('--inputX')
    parser.add_argument('--inputY')
    parser.add_argument('--head')
    parser.add_argument('--tail')
    parser.add_argument('--priority')
    parser.add_argument('--status')

    args = vars(parser.parse_args())
    mavisEntities={}
    currentUser = getpass.getuser()
    print args
    mavisArgs=[int(x) for x in args['entities'].split(",")]
    mavisData = conn.getByIds(mavisArgs)

    for item in mavisData:
        mavisEntities[item['type']]=item

    out=None
    if args.has_key('outputPath') and args['outputPath'] !=None:
        out = args['outputPath']
    importPlateAction(mavisEntities, outputPath=out)

    sys.exit()
